from mgarch.mgarch import mgarch

if __name__ == "__main__":
    print('DCC-GARCH')